//
//  SVW_LoginInputFooterView.h


#import <UIKit/UIKit.h>

@interface SVW_LoginInputFooterView : UITableViewHeaderFooterView<SVW_ViewProtocol>

/**
 查询按钮
 */
@property (nonatomic, strong) UIButton *queryBtn;

@end
