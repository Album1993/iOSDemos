//
//  SVW_TableViewProtocol.h

#import <Foundation/Foundation.h>

@protocol SVW_TableViewProtocol <SVW_ViewProtocol>

/**
 针对TableView 添加自定义协议方法
 */

@end
