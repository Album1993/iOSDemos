//
//  SVW_TableViewCellProtocol.h

#import <Foundation/Foundation.h>

@protocol SVW_TableViewCellProtocol <SVW_ViewProtocol>

/**
 针对TableViewCell 添加自定义协议方法
 */

@end
