//
//  UIView+NonBase.h

#import <UIKit/UIKit.h>

// 获取当前数据源的下标
FOUNDATION_EXTERN NSString *const SVW_UIView_DataSourceArrayIndexKey;


@interface UIView (NonBase)

@end
