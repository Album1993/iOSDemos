//
//  UIView+NonBase.m

#import "UIView+NonBase.h"

NSString *const SVW_UIView_DataSourceArrayIndexKey = @"SVW_UIView_DataSourceArrayIndexKey";


@implementation UIView (NonBase)

@end
