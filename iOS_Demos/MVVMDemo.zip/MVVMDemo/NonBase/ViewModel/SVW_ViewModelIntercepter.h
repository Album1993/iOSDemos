//
//  SVW_ViewModelIntercepter.h

#import <Foundation/Foundation.h>


@interface SVW_ViewModelIntercepter : NSObject

@end
