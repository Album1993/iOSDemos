//
//  UIImage+SVW_Color.h

#import <UIKit/UIKit.h>


@interface UIImage (SVW_Color)

+ (UIImage *)imageWithColor:(UIColor *)color;

@end
